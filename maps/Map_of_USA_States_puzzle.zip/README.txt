                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1653054
Map of USA States puzzle by remyspencer is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Multi-state map of the US. I looked around for just the plain, individual states scaled correctly to fit with one another, but couldn't find a thing that had that. I borrowed the sketchup file from the creator to make this.

Would be great for a learning tool for identifying state shapes and locations, or as a puzzle for kids.

The states are scaled to be pretty large. If you scale them down, make sure to use the same scale for every model.

Massachusetts isn't scaled properly - sorry. I'll fix this eventually. I used a rough estimate of the appropriate dimensions to print the one for the map.

# Print Settings

Rafts: Doesn't Matter
Supports: Doesn't Matter

# How I Designed This

I borrowed the sketchup file from the creator, then singled out the states and extruded them to a certain height (I think like 3mm) and exported to STL. Afterwards I loaded each state individually into 123D Design for scaling to the proper dimensions so everything would fit together seamlessly.